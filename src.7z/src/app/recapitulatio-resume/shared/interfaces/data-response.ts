export interface DataResponse {
  title: string;
  body: string;
  type: string;
  config?: string;
}
