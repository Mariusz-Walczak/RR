export interface ContactForm {
  name: string;
  company?: string;
  phone: string;
  mail: string;
  body: string;
}
