export interface MenuDataElement {
  id: string;
  title: string;
  textId: string;
}
